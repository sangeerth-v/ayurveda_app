@extends('layouts.app')

@section('navbar')
    @include('partials.nav-public')
@endsection

@section('title', 'Book Doctor | Ayurveda')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="card-header py-4" style="background: linear-gradient(135deg, #1a4d2e, #4f772d);">
                <h4 class="mb-0 text-white fw-bold">
                    <i class="fas fa-calendar-plus me-2"></i> Book Appointment
                </h4>
            </div>
            <div class="card-body p-4">
                {{-- Doctor Summary --}}
                <div class="d-flex align-items-center gap-3 p-3 rounded-3 mb-4" style="background: #f0f7f4;">
                    <div class="rounded-circle d-flex align-items-center justify-content-center" style="width:60px;height:60px;background:#1a4d2e;">
                        <i class="fas fa-user-md fa-lg text-white"></i>
                    </div>
                    <div>
                        <h5 class="mb-1 fw-bold" style="color:#1a4d2e;">Dr. {{ $doctor->name }}</h5>
                        <p class="mb-0 text-muted small">
                            {{ $doctor->specialization_category ?? 'General' }} &bull; {{ $doctor->district->name ?? '' }}
                        </p>
                        <p class="mb-0 text-muted small">
                            <i class="fas fa-rupee-sign me-1"></i>{{ number_format($doctor->consultation_fee, 2) }} consultation fee
                            @if($doctor->available_time)
                                &bull; <i class="fas fa-clock me-1"></i>Available: 
                                @php
                                    $times = explode(' to ', $doctor->available_time);
                                    if(count($times) == 2) {
                                        echo \Carbon\Carbon::parse(trim($times[0]))->format('h:i A') . ' - ' . \Carbon\Carbon::parse(trim($times[1]))->format('h:i A');
                                    } else {
                                        echo $doctor->available_time;
                                    }
                                @endphp
                            @endif
                        </p>
                    </div>
                </div>

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('bookings.store') }}" method="POST">
                    @csrf
                    <input type="hidden" name="doctor_id" value="{{ $doctor->id }}">

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Appointment Date</label>
                            <input type="date"
                                   name="booking_date"
                                   id="booking_date"
                                   class="form-control @error('booking_date') is-invalid @enderror"
                                   min="{{ date('Y-m-d') }}"
                                   max="{{ date('Y-m-t', strtotime('+3 months')) }}"
                                   value="{{ old('booking_date', date('Y-m-d')) }}"
                                   required>
                            @error('booking_date')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Select Appointment Time</label>
                            <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 g-2" id="time-slots-container">
                                @foreach($slots as $slot)
                                    <div class="col">
                                        <input type="radio" name="booking_time" value="{{ $slot }}" id="slot-{{ str_replace(':', '-', $slot) }}" class="btn-check" required>
                                        <label class="btn btn-outline-success w-100 py-2 rounded-3 shadow-sm time-slot-label" for="slot-{{ str_replace(':', '-', $slot) }}" data-slot="{{ $slot }}">
                                            {{ \Carbon\Carbon::parse($slot)->format('h:i A') }}
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                            @error('booking_time')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="mt-4 d-flex gap-2">
                        <button type="submit" class="btn btn-success px-4 fw-semibold shadow-sm">
                            <i class="fas fa-check-circle me-2"></i>Confirm Booking
                        </button>
                        <a href="{{ route('home') }}" class="btn btn-outline-secondary px-4">Cancel</a>
                    </div>
                </form>

                <style>
                    .time-slot-label.booked {
                        background-color: #f8f9fa !important;
                        border-color: #dee2e6 !important;
                        color: #adb5bd !important;
                        opacity: 0.5 !important;
                        cursor: not-allowed !important;
                        pointer-events: none !important;
                        box-shadow: inset 0 2px 4px rgba(0,0,0,0.05) !important;
                    }
                </style>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const bookedData = {!! $bookedSlots->toJson() !!};
                        const leaveDates = {!! json_encode($unavailabilities) !!};
                        const dateInput = document.getElementById('booking_date');
                        const timeSlotsContainer = document.getElementById('time-slots-container');
                        const slotLabels = timeSlotsContainer.querySelectorAll('.time-slot-label');
                        const submitBtn = document.querySelector('button[type="submit"]');

                        function updateSlots() {
                            const selectedDate = dateInput.value;
                            if(!selectedDate) return;

                            const isUnavailable = leaveDates.includes(selectedDate);
                            
                            // Handle Leave Dates
                            if (isUnavailable) {
                                timeSlotsContainer.innerHTML = `
                                    <div class="col-12 w-100 mt-2">
                                        <div class="alert alert-danger border-0 shadow-sm rounded-4 d-flex align-items-center py-4">
                                            <i class="fas fa-calendar-times fa-3x me-4 opacity-50"></i>
                                            <div>
                                                <h5 class="fw-bold mb-1">Doctor is Unavailable</h5>
                                                <p class="mb-0 small opcaity-75">The doctor has marked this date as a leave. Please select another date for your appointment.</p>
                                            </div>
                                        </div>
                                    </div>
                                `;
                                submitBtn.disabled = true;
                                submitBtn.classList.add('opacity-50');
                                return;
                            } else {
                                // Restore slots HTML if it was replaced
                                if (timeSlotsContainer.querySelector('.alert-danger')) {
                                    location.reload(); // Simplest way to restore slots and logic
                                    return;
                                }
                            }

                            const now = new Date();
                            const todayStr = now.toLocaleDateString('en-CA'); // Gets YYYY-MM-DD in local time
                            const currentTimeStr = now.getHours().toString().padStart(2, '0') + ":" + now.getMinutes().toString().padStart(2, '0');

                            slotLabels.forEach(label => {
                                const slotTime = label.getAttribute('data-slot'); // e.g. "09:00"
                                const radioInput = document.getElementById(label.getAttribute('for'));
                                
                                // Check if this slot for the selected date is in bookedData
                                const isBooked = bookedData.some(b => {
                                    const bookedTimeNormalized = b.booking_time.substring(0, 5);
                                    const slotTimeNormalized = slotTime.substring(0, 5);
                                    return b.booking_date === selectedDate && bookedTimeNormalized === slotTimeNormalized;
                                });

                                // Check if slot is in the past for today
                                const isPast = (selectedDate === todayStr && slotTime < currentTimeStr);
                                
                                if(isBooked || isPast) {
                                    radioInput.disabled = true;
                                    radioInput.checked = false;
                                    label.classList.add('booked');
                                } else {
                                    radioInput.disabled = false;
                                    label.classList.remove('booked');
                                }
                            });
                            
                            submitBtn.disabled = false;
                            submitBtn.classList.remove('opacity-50');
                        }

                        dateInput.addEventListener('change', updateSlots);
                        updateSlots(); // Initialize on load
                    });
                </script>
            </div>
        </div>
    </div>
</div>
@endsection
