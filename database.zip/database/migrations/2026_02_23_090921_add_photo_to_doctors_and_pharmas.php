<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('doctors', function (Blueprint $table) {
            $table->string('photo')->nullable()->after('email');
        });

        Schema::table('pharma_companies', function (Blueprint $table) {
            $table->string('logo')->nullable()->after('email');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('doctors', function (Blueprint $table) {
            $table->dropColumn('photo');
        });

        Schema::table('pharma_companies', function (Blueprint $table) {
            $table->dropColumn('logo');
        });
    }
};
